import os

# Main Settings

os.environ["SECRET_KEY"] = "TV4UWorldDjnagoApplication"
os.environ["DEBUG"] = "0"

# AWS S3 Settings

# Main Settings
os.environ["AWS_ACCESS_KEY_ID"] = 'AKIAWXOZMZ76VACKYXPW'
os.environ["AWS_SECRET_ACCESS_KEY"] = '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'
os.environ["AWS_STORAGE_BUCKET_NAME"] = 'iptvpozna'
os.environ["AWS_S3_REGION_NAME"] = 'eu-west-1'

# S3 Addition Settings
os.environ["AWS_S3_CUSTOM_DOMAIN"] = ''  
os.environ["AWS_DEFAULT_ACL"] = ''  
os.environ["AWS_QUERYSTRING_AUTH"] = 'False'  
os.environ["AWS_S3_FILE_OVERWRITE"] = 'False' 
os.environ["AWS_S3_SIGNATURE_VERSION"] = '' 

# Google ReCaptcha

os.environ["RECAPTCHA_PUBLIC_KEY"] = "6LfJeuUnAAAAAI_2CUofwHTwR9_5qGyPvvDfG3QJ"
os.environ["RECAPTCHA_PRIVATE_KEY"] = "6LfJeuUnAAAAAJHNGFGbwy7LSW84vI2sCHG2S-Hw"


# # PayPal Live
# os.environ['PAYPAL_CLIENT_ID'] = 'AcFwNSw8EkXYs-XvMHMmNdcxuDgYheA37j3-hx1HltsPQ2D__Y3b4ud5bUje70UxNCXaKYDJvJRbVtWM'
# os.environ['PAYPAL_SECRET_KEY'] = 'EEVWfj89_6dxLCZvwYCDAFkOvEHPIG9_2ZCXK32zoUpQ1tDKt8mkcJwOQCs_jghcB5PqM_ca4Ww23ckp'

# Iznad ovog komentara ne mjenjaj, samo ispod ovog komentara mjenjaj


# Email Settings

os.environ["ADMIN_EMAIL"] = "tonnyg1995@gmail.com"
os.environ["EMAIL_BACKEND"] = "django.core.mail.backends.smtp.EmailBackend"
os.environ["EMAIL_HOST"] = "smtp.hostinger.com"
os.environ["EMAIL_PORT"] = str(587)
os.environ["EMAIL_USE_TLS"] = "False"
os.environ["EMAIL_HOST_USER"] = "hr@bdm.network"
os.environ["EMAIL_HOST_PASSWORD"] = "twkC@LW4uPs^WXgLaSN$"


# PayPal Sendbox
os.environ['PAYPAL_CLIENT_ID'] = 'ARXxQusXBc0JkwWgKPp9wHvxguJDzEZQh6e5_yhsYNRsBNFptsek-XLIZyQem_TlOeVuOMl_buo7aD0R'
os.environ['PAYPAL_SECRET_KEY'] = 'EEK0lGXBT_DcaKfg8IXkcFsLkXYpP840NjsXv5G_fdzSMkGWyqctrWhE4abgKj5m07IbaW_rb4VJ6jZR'